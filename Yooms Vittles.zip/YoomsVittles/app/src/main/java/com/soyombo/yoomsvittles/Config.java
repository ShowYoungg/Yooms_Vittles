package com.soyombo.yoomsvittles;

public class Config {
    public static final String EMAIL ="showy4show@gmail.com";
    public static final String PASSWORD ="FunmiOluwa321%";
    //https://myaccount.google.com/lesssecureapps
}